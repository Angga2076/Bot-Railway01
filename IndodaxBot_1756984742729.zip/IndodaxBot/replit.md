# Overview

This is a Telegram bot that integrates with the Indodax cryptocurrency exchange API. The bot provides users with cryptocurrency market data and trading functionality through Telegram chat interface. It uses the pyTeleBot library for Telegram bot functionality and implements secure API communication with Indodax exchange using HMAC-SHA512 authentication.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Framework
The application is built using pyTeleBot (telebot), a Python Telegram Bot API wrapper. This provides a simple interface for handling Telegram messages, commands, and user interactions through a chat-based interface.

## API Integration Layer
The system implements a custom `IndodaxAPI` class that handles authentication and communication with the Indodax cryptocurrency exchange. Key architectural decisions include:

- **HMAC-SHA512 Authentication**: Uses industry-standard cryptographic signing for secure API requests
- **Timestamp-based Security**: Includes millisecond timestamps in API requests to prevent replay attacks
- **Modular API Client**: Separates API logic into a dedicated class for better maintainability

## Security Architecture
- **Environment Variable Configuration**: Sensitive credentials (bot token, API keys) are stored as environment variables rather than hardcoded
- **Input Validation**: Validates required environment variables at startup to fail fast if misconfigured
- **Cryptographic Signing**: All private API requests are signed using HMAC with SHA512 hashing

## Error Handling Strategy
The application implements defensive programming practices with proper validation of required configuration parameters, raising clear error messages when essential environment variables are missing.

## Single-File Architecture
The current implementation uses a monolithic single-file approach, keeping all functionality in one Python file. This simplifies deployment but may need refactoring as the bot grows in complexity.

# External Dependencies

## Telegram Bot API
- **Service**: Telegram Bot Platform
- **Purpose**: Provides chat interface for user interactions
- **Authentication**: Bot token-based authentication
- **Integration**: Real-time message handling and response

## Indodax Exchange API
- **Service**: Indodax Cryptocurrency Exchange
- **Purpose**: Cryptocurrency market data and trading operations
- **Authentication**: API key and secret with HMAC-SHA512 signing
- **Endpoints**: Public ticker API and private trading API

## Python Libraries
- **pyTeleBot**: Telegram Bot API wrapper for Python
- **requests**: HTTP client library for API communications
- **hashlib**: Cryptographic hashing functions (SHA512)
- **hmac**: Hash-based message authentication
- **urllib.parse**: URL encoding utilities for API parameters

## Runtime Environment
- **Platform**: Replit Python environment
- **Configuration**: Environment variables for secure credential storage
- **Dependencies**: Standard Python libraries plus pyTeleBot package