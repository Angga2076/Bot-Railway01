import telebot
import requests
import hashlib
import hmac
import time
import os
import urllib.parse
from typing import Dict, Any, Optional
from telebot import types

# Bot configuration - validate environment variables
BOT_TOKEN = os.getenv('BOT_TOKEN')
INDODAX_API_KEY = os.getenv('INDODAX_API_KEY')
INDODAX_SECRET_KEY = os.getenv('INDODAX_SECRET_KEY')

if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN environment variable is required")
if not INDODAX_API_KEY:
    raise ValueError("INDODAX_API_KEY environment variable is required")
if not INDODAX_SECRET_KEY:
    raise ValueError("INDODAX_SECRET_KEY environment variable is required")

# Initialize bot
bot = telebot.TeleBot(BOT_TOKEN)

# Indodax API URLs
INDODAX_BASE_URL = "https://indodax.com"
TICKER_URL = f"{INDODAX_BASE_URL}/api/ticker"
PRIVATE_URL = f"{INDODAX_BASE_URL}/tapi"

class IndodaxAPI:
    def __init__(self, api_key: str, secret_key: str):
        self.api_key = api_key
        self.secret_key = secret_key
    
    def _generate_signature(self, data: str) -> str:
        """Generate HMAC signature for API request"""
        return hmac.new(
            self.secret_key.encode('utf-8'),
            data.encode('utf-8'),
            hashlib.sha512
        ).hexdigest()
    
    def _make_private_request(self, method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make authenticated request to Indodax private API"""
        if params is None:
            params = {}
        
        params['method'] = method
        params['timestamp'] = str(int(time.time() * 1000))  # milliseconds
        params['recvWindow'] = '5000'
        
        # Create post data like PHP http_build_query
        post_data = urllib.parse.urlencode(params)
        
        # Generate signature using post_data string
        signature = self._generate_signature(post_data)
        
        headers = {
            'Key': self.api_key,
            'Sign': signature,
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        
        try:
            response = requests.post(PRIVATE_URL, data=params, headers=headers, timeout=10)
            return response.json()
        except Exception as e:
            return {'success': 0, 'error': str(e)}
    
    def get_balance(self) -> Dict[str, Any]:
        """Get account balance"""
        return self._make_private_request('getInfo')
    
    def get_ticker(self, pair: str) -> Dict[str, Any]:
        """Get ticker data for specific pair"""
        try:
            # Use ticker_all endpoint since individual ticker endpoints return invalid_pair
            response = requests.get(f"{TICKER_URL}_all", timeout=10)
            if response.status_code == 200:
                data = response.json()
                
                if 'tickers' in data:
                    tickers = data['tickers']
                    
                    # Try different pair formats
                    pair_formats = [
                        pair,                    # Original format: btc_idr
                        pair.replace('_', ''),   # No underscore: btcidr
                        pair.upper(),            # Uppercase: BTC_IDR
                        pair.replace('_', '').upper()  # Uppercase no underscore: BTCIDR
                    ]
                    
                    for pair_format in pair_formats:
                        if pair_format in tickers:
                            return {'ticker': tickers[pair_format]}
                    
                    # If not found, return available pairs for debugging
                    available_pairs = [p for p in tickers.keys() if pair.split('_')[0].lower() in p.lower()]
                    return {'error': f'Pair {pair} not found. Available: {available_pairs[:5]}'}
                else:
                    return {'error': 'No tickers data in response'}
            else:
                return {'error': f'API returned status {response.status_code}'}
                
        except Exception as e:
            return {'error': str(e)}
    
    def place_order(self, pair: str, order_type: str, price: float, amount: float) -> Dict[str, Any]:
        """Place buy/sell order"""
        params = {
            'pair': pair,
            'type': order_type,
            'price': str(price),
        }
        
        # Add appropriate amount parameter based on order type
        if order_type == 'buy':
            params['idr'] = str(int(price * amount))  # IDR amount for buying
        else:
            params[pair.split('_')[0]] = str(amount)  # Crypto amount for selling
        
        return self._make_private_request('trade', params)

# Initialize Indodax API
indodax = IndodaxAPI(INDODAX_API_KEY, INDODAX_SECRET_KEY)

def create_main_keyboard():
    """Create main menu keyboard"""
    keyboard = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
    
    # Balance and prices
    balance_btn = types.KeyboardButton('💰 Balance')
    btc_price_btn = types.KeyboardButton('📈 Harga BTC')
    sol_price_btn = types.KeyboardButton('📉 Harga SOL')
    
    # Direct trading buttons - 50% and 100%
    buy_btc_50_btn = types.KeyboardButton('🟢 Buy BTC 50%')
    buy_btc_100_btn = types.KeyboardButton('🟢 Buy BTC 100%')
    sell_btc_100_btn = types.KeyboardButton('🔴 Sell BTC 100%')
    
    buy_sol_50_btn = types.KeyboardButton('🟢 Buy SOL 50%')
    buy_sol_100_btn = types.KeyboardButton('🟢 Buy SOL 100%')
    sell_sol_100_btn = types.KeyboardButton('🔴 Sell SOL 100%')
    
    # Quick trade buttons
    buy_btc_100k_btn = types.KeyboardButton('💚 Buy BTC 100rb')
    sell_all_btn = types.KeyboardButton('💸 Jual Semua')
    
    keyboard.add(balance_btn)
    keyboard.add(btc_price_btn, sol_price_btn)
    keyboard.add(buy_btc_50_btn, buy_btc_100_btn)
    keyboard.add(sell_btc_100_btn)
    keyboard.add(buy_sol_50_btn, buy_sol_100_btn)
    keyboard.add(sell_sol_100_btn)
    keyboard.add(buy_btc_100k_btn, sell_all_btn)
    
    return keyboard

def format_number(num: float) -> str:
    """Format number with commas"""
    return "{:,.0f}".format(float(num))

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    """Send welcome message with main menu"""
    welcome_text = """
🤖 *Bot Trading Real-time Indodax*

Trading langsung di harga real-time:
💰 Balance - Cek saldo
📈 Harga BTC - Harga live BTC/IDR
📉 Harga SOL - Harga live SOL/IDR
🟢 Buy BTC 50% - Beli BTC 50% IDR
🟢 Buy BTC 100% - Beli BTC semua IDR
🔴 Sell BTC 100% - Jual semua BTC
🟢 Buy SOL 50% - Beli SOL 50% IDR
🟢 Buy SOL 100% - Beli SOL semua IDR
🔴 Sell SOL 100% - Jual semua SOL
💚 Buy BTC 100rb - Beli BTC Rp 100ribu
💸 Jual Semua - Jual semua crypto

Semua order real-time di harga live Indodax!
    """
    
    bot.reply_to(message, welcome_text, parse_mode='Markdown', reply_markup=create_main_keyboard())

@bot.message_handler(func=lambda message: message.text == '💰 Balance')
def show_balance(message):
    """Show account balance"""
    bot.reply_to(message, "⏳ Mengambil data balance...")
    
    balance_data = indodax.get_balance()
    
    if balance_data.get('success') == 1:
        balance = balance_data.get('return', {}).get('balance', {})
        
        btc_balance = float(balance.get('btc', 0))
        sol_balance = float(balance.get('sol', 0))
        idr_balance = float(balance.get('idr', 0))
        
        balance_text = f"""
💰 BALANCE AKUN

🪙 BTC: {btc_balance:.8f}
🔥 SOL: {sol_balance:.4f}
💵 IDR: Rp {format_number(idr_balance)}
        """
        
        bot.reply_to(message, balance_text)
    else:
        error_msg = balance_data.get('error', 'Gagal mengambil data balance')
        bot.reply_to(message, f"❌ Error: {error_msg}")

@bot.message_handler(func=lambda message: message.text == '📈 Harga BTC')
def show_btc_price(message):
    """Show BTC/IDR price"""
    bot.reply_to(message, "⏳ Mengambil harga BTC...")
    
    ticker_data = indodax.get_ticker('btc_idr')
    
    if 'ticker' in ticker_data:
        ticker = ticker_data['ticker']
        last_price = float(ticker.get('last', 0))
        high = float(ticker.get('high', 0))
        low = float(ticker.get('low', 0))
        vol_btc = float(ticker.get('vol_btc', 0))
        
        price_text = f"""
📈 HARGA BTC/IDR REAL-TIME

💰 Last: Rp {format_number(last_price)}
📊 High 24h: Rp {format_number(high)}
📉 Low 24h: Rp {format_number(low)}
📦 Volume: {vol_btc:.4f} BTC
        """
        
        bot.reply_to(message, price_text)
    else:
        error_msg = ticker_data.get('error', 'Gagal mengambil harga BTC')
        bot.reply_to(message, f"❌ Error: {error_msg}")

@bot.message_handler(func=lambda message: message.text == '📉 Harga SOL')
def show_sol_price(message):
    """Show SOL/IDR price"""
    bot.reply_to(message, "⏳ Mengambil harga SOL...")
    
    ticker_data = indodax.get_ticker('sol_idr')
    
    if 'ticker' in ticker_data:
        ticker = ticker_data['ticker']
        last_price = float(ticker.get('last', 0))
        high = float(ticker.get('high', 0))
        low = float(ticker.get('low', 0))
        vol_sol = float(ticker.get('vol_sol', 0))
        
        price_text = f"""
📉 HARGA SOL/IDR REAL-TIME

💰 Last: Rp {format_number(last_price)}
📊 High 24h: Rp {format_number(high)}
📉 Low 24h: Rp {format_number(low)}
📦 Volume: {vol_sol:.4f} SOL
        """
        
        bot.reply_to(message, price_text)
    else:
        error_msg = ticker_data.get('error', 'Gagal mengambil harga SOL')
        bot.reply_to(message, f"❌ Error: {error_msg}")

@bot.message_handler(func=lambda message: message.text == '🟢 Buy BTC 50%')
def buy_btc_50(message):
    """Buy BTC with 50% of IDR balance"""
    bot.reply_to(message, "⏳ Buy BTC 50% di harga real-time...")
    
    # Get balance and price
    balance_data = indodax.get_balance()
    if balance_data.get('success') != 1:
        bot.reply_to(message, "❌ Gagal mengambil balance", reply_markup=create_main_keyboard())
        return
    
    idr_balance = float(balance_data.get('return', {}).get('balance', {}).get('idr', 0))
    
    if idr_balance < 10000:
        bot.reply_to(message, f"❌ IDR tidak cukup: Rp {format_number(idr_balance)}", reply_markup=create_main_keyboard())
        return
    
    ticker_data = indodax.get_ticker('btc_idr')
    if 'ticker' not in ticker_data:
        bot.reply_to(message, "❌ Gagal mengambil harga BTC", reply_markup=create_main_keyboard())
        return
    
    last_price = float(ticker_data['ticker'].get('last', 0))
    idr_to_spend = (idr_balance * 50 / 100) * 0.998  # 50% with fee buffer
    amount = idr_to_spend / last_price
    
    # Place order
    order_result = indodax.place_order('btc_idr', 'buy', last_price, amount)
    
    if order_result.get('success') == 1:
        order_info = order_result.get('return', {})
        executed_price = float(order_info.get('order_price', last_price))
        executed_amount = float(order_info.get('remain_btc', amount))
        actual_total = executed_price * executed_amount
        actual_percentage = (actual_total / idr_balance) * 100 if idr_balance > 0 else 0
        
        success_text = f"""
✅ BUY BTC 50% BERHASIL
📊 HARGA REAL INDODAX

🪙 Amount: {executed_amount:.8f} BTC
💰 Harga: Rp {format_number(executed_price)}
💵 Total: Rp {format_number(actual_total)}
📈 Persentase: {actual_percentage:.2f}%
🆔 Order ID: {order_info.get('order_id', 'N/A')}
        """
        
        bot.reply_to(message, success_text, reply_markup=create_main_keyboard())
    else:
        error_msg = order_result.get('error', 'Gagal buy')
        bot.reply_to(message, f"❌ Error: {error_msg}", reply_markup=create_main_keyboard())

@bot.message_handler(func=lambda message: message.text == '🟢 Buy BTC 100%')
def buy_btc_100(message):
    """Buy BTC with 100% of IDR balance"""
    bot.reply_to(message, "⏳ Buy BTC 100% di harga real-time...")
    
    # Get balance and price
    balance_data = indodax.get_balance()
    if balance_data.get('success') != 1:
        bot.reply_to(message, "❌ Gagal mengambil balance", reply_markup=create_main_keyboard())
        return
    
    idr_balance = float(balance_data.get('return', {}).get('balance', {}).get('idr', 0))
    
    if idr_balance < 10000:
        bot.reply_to(message, f"❌ IDR tidak cukup: Rp {format_number(idr_balance)}", reply_markup=create_main_keyboard())
        return
    
    ticker_data = indodax.get_ticker('btc_idr')
    if 'ticker' not in ticker_data:
        bot.reply_to(message, "❌ Gagal mengambil harga BTC", reply_markup=create_main_keyboard())
        return
    
    last_price = float(ticker_data['ticker'].get('last', 0))
    idr_to_spend = idr_balance * 0.998  # 100% with fee buffer
    amount = idr_to_spend / last_price
    
    # Place order
    order_result = indodax.place_order('btc_idr', 'buy', last_price, amount)
    
    if order_result.get('success') == 1:
        order_info = order_result.get('return', {})
        executed_price = float(order_info.get('order_price', last_price))
        executed_amount = float(order_info.get('remain_btc', amount))
        actual_total = executed_price * executed_amount
        
        success_text = f"""
✅ BUY BTC 100% BERHASIL
📊 HARGA REAL INDODAX

🪙 Amount: {executed_amount:.8f} BTC
💰 Harga: Rp {format_number(executed_price)}
💵 Total: Rp {format_number(actual_total)}
💯 Menggunakan semua IDR balance
🆔 Order ID: {order_info.get('order_id', 'N/A')}
        """
        
        bot.reply_to(message, success_text, reply_markup=create_main_keyboard())
    else:
        error_msg = order_result.get('error', 'Gagal buy')
        bot.reply_to(message, f"❌ Error: {error_msg}", reply_markup=create_main_keyboard())

@bot.message_handler(func=lambda message: message.text == '🔴 Sell BTC 100%')
def sell_btc_100(message):
    """Sell all BTC"""
    bot.reply_to(message, "⏳ Sell BTC 100% di harga real-time...")
    
    # Get balance and price
    balance_data = indodax.get_balance()
    if balance_data.get('success') != 1:
        bot.reply_to(message, "❌ Gagal mengambil balance", reply_markup=create_main_keyboard())
        return
    
    btc_balance = float(balance_data.get('return', {}).get('balance', {}).get('btc', 0))
    
    if btc_balance < 0.00001:
        bot.reply_to(message, f"❌ BTC tidak cukup: {btc_balance:.8f}", reply_markup=create_main_keyboard())
        return
    
    ticker_data = indodax.get_ticker('btc_idr')
    if 'ticker' not in ticker_data:
        bot.reply_to(message, "❌ Gagal mengambil harga BTC", reply_markup=create_main_keyboard())
        return
    
    last_price = float(ticker_data['ticker'].get('last', 0))
    
    # Place sell order
    order_result = indodax.place_order('btc_idr', 'sell', last_price, btc_balance)
    
    if order_result.get('success') == 1:
        order_info = order_result.get('return', {})
        executed_price = float(order_info.get('order_price', last_price))
        executed_amount = float(order_info.get('remain_btc', btc_balance))
        actual_total_idr = executed_price * executed_amount
        
        success_text = f"""
✅ SELL BTC 100% BERHASIL
📊 HARGA REAL INDODAX

🪙 Amount: {executed_amount:.8f} BTC
💰 Harga: Rp {format_number(executed_price)}
💵 Total: Rp {format_number(actual_total_idr)}
🆔 Order ID: {order_info.get('order_id', 'N/A')}
        """
        
        bot.reply_to(message, success_text, reply_markup=create_main_keyboard())
    else:
        error_msg = order_result.get('error', 'Gagal sell')
        bot.reply_to(message, f"❌ Error: {error_msg}", reply_markup=create_main_keyboard())

@bot.message_handler(func=lambda message: message.text == '🟢 Buy SOL 50%')
def buy_sol_50(message):
    """Buy SOL with 50% of IDR balance"""
    bot.reply_to(message, "⏳ Buy SOL 50% di harga real-time...")
    
    # Get balance and price
    balance_data = indodax.get_balance()
    if balance_data.get('success') != 1:
        bot.reply_to(message, "❌ Gagal mengambil balance", reply_markup=create_main_keyboard())
        return
    
    idr_balance = float(balance_data.get('return', {}).get('balance', {}).get('idr', 0))
    
    if idr_balance < 10000:
        bot.reply_to(message, f"❌ IDR tidak cukup: Rp {format_number(idr_balance)}", reply_markup=create_main_keyboard())
        return
    
    ticker_data = indodax.get_ticker('sol_idr')
    if 'ticker' not in ticker_data:
        bot.reply_to(message, "❌ Gagal mengambil harga SOL", reply_markup=create_main_keyboard())
        return
    
    last_price = float(ticker_data['ticker'].get('last', 0))
    idr_to_spend = (idr_balance * 50 / 100) * 0.998  # 50% with fee buffer
    amount = idr_to_spend / last_price
    
    # Place order
    order_result = indodax.place_order('sol_idr', 'buy', last_price, amount)
    
    if order_result.get('success') == 1:
        order_info = order_result.get('return', {})
        executed_price = float(order_info.get('order_price', last_price))
        executed_amount = float(order_info.get('remain_sol', amount))
        actual_total = executed_price * executed_amount
        actual_percentage = (actual_total / idr_balance) * 100 if idr_balance > 0 else 0
        
        success_text = f"""
✅ BUY SOL 50% BERHASIL
📊 HARGA REAL INDODAX

🔥 Amount: {executed_amount:.6f} SOL
💰 Harga: Rp {format_number(executed_price)}
💵 Total: Rp {format_number(actual_total)}
📈 Persentase: {actual_percentage:.2f}%
🆔 Order ID: {order_info.get('order_id', 'N/A')}
        """
        
        bot.reply_to(message, success_text, reply_markup=create_main_keyboard())
    else:
        error_msg = order_result.get('error', 'Gagal buy')
        bot.reply_to(message, f"❌ Error: {error_msg}", reply_markup=create_main_keyboard())

@bot.message_handler(func=lambda message: message.text == '🟢 Buy SOL 100%')
def buy_sol_100(message):
    """Buy SOL with 100% of IDR balance"""
    bot.reply_to(message, "⏳ Buy SOL 100% di harga real-time...")
    
    # Get balance and price
    balance_data = indodax.get_balance()
    if balance_data.get('success') != 1:
        bot.reply_to(message, "❌ Gagal mengambil balance", reply_markup=create_main_keyboard())
        return
    
    idr_balance = float(balance_data.get('return', {}).get('balance', {}).get('idr', 0))
    
    if idr_balance < 10000:
        bot.reply_to(message, f"❌ IDR tidak cukup: Rp {format_number(idr_balance)}", reply_markup=create_main_keyboard())
        return
    
    ticker_data = indodax.get_ticker('sol_idr')
    if 'ticker' not in ticker_data:
        bot.reply_to(message, "❌ Gagal mengambil harga SOL", reply_markup=create_main_keyboard())
        return
    
    last_price = float(ticker_data['ticker'].get('last', 0))
    idr_to_spend = idr_balance * 0.998  # 100% with fee buffer
    amount = idr_to_spend / last_price
    
    # Place order
    order_result = indodax.place_order('sol_idr', 'buy', last_price, amount)
    
    if order_result.get('success') == 1:
        order_info = order_result.get('return', {})
        executed_price = float(order_info.get('order_price', last_price))
        executed_amount = float(order_info.get('remain_sol', amount))
        actual_total = executed_price * executed_amount
        
        success_text = f"""
✅ BUY SOL 100% BERHASIL
📊 HARGA REAL INDODAX

🔥 Amount: {executed_amount:.6f} SOL
💰 Harga: Rp {format_number(executed_price)}
💵 Total: Rp {format_number(actual_total)}
💯 Menggunakan semua IDR balance
🆔 Order ID: {order_info.get('order_id', 'N/A')}
        """
        
        bot.reply_to(message, success_text, reply_markup=create_main_keyboard())
    else:
        error_msg = order_result.get('error', 'Gagal buy')
        bot.reply_to(message, f"❌ Error: {error_msg}", reply_markup=create_main_keyboard())

@bot.message_handler(func=lambda message: message.text == '🔴 Sell SOL 100%')
def sell_sol_100(message):
    """Sell all SOL"""
    bot.reply_to(message, "⏳ Sell SOL 100% di harga real-time...")
    
    # Get balance and price
    balance_data = indodax.get_balance()
    if balance_data.get('success') != 1:
        bot.reply_to(message, "❌ Gagal mengambil balance", reply_markup=create_main_keyboard())
        return
    
    sol_balance = float(balance_data.get('return', {}).get('balance', {}).get('sol', 0))
    
    if sol_balance < 0.001:
        bot.reply_to(message, f"❌ SOL tidak cukup: {sol_balance:.6f}", reply_markup=create_main_keyboard())
        return
    
    ticker_data = indodax.get_ticker('sol_idr')
    if 'ticker' not in ticker_data:
        bot.reply_to(message, "❌ Gagal mengambil harga SOL", reply_markup=create_main_keyboard())
        return
    
    last_price = float(ticker_data['ticker'].get('last', 0))
    
    # Place sell order
    order_result = indodax.place_order('sol_idr', 'sell', last_price, sol_balance)
    
    if order_result.get('success') == 1:
        order_info = order_result.get('return', {})
        executed_price = float(order_info.get('order_price', last_price))
        executed_amount = float(order_info.get('remain_sol', sol_balance))
        actual_total_idr = executed_price * executed_amount
        
        success_text = f"""
✅ SELL SOL 100% BERHASIL
📊 HARGA REAL INDODAX

🔥 Amount: {executed_amount:.6f} SOL
💰 Harga: Rp {format_number(executed_price)}
💵 Total: Rp {format_number(actual_total_idr)}
🆔 Order ID: {order_info.get('order_id', 'N/A')}
        """
        
        bot.reply_to(message, success_text, reply_markup=create_main_keyboard())
    else:
        error_msg = order_result.get('error', 'Gagal sell')
        bot.reply_to(message, f"❌ Error: {error_msg}", reply_markup=create_main_keyboard())

@bot.message_handler(func=lambda message: message.text == '💚 Buy BTC 100rb')
def buy_btc_100k(message):
    """Buy BTC with 100rb IDR"""
    bot.reply_to(message, "⏳ Buy BTC Rp 100rb di harga real-time...")
    
    # Get balance and price
    balance_data = indodax.get_balance()
    if balance_data.get('success') != 1:
        bot.reply_to(message, "❌ Gagal mengambil balance", reply_markup=create_main_keyboard())
        return
    
    idr_balance = float(balance_data.get('return', {}).get('balance', {}).get('idr', 0))
    required_amount = 100000
    
    if idr_balance < required_amount:
        bot.reply_to(message, f"❌ IDR tidak cukup: Rp {format_number(idr_balance)}\nButuh: Rp {format_number(required_amount)}", 
                     reply_markup=create_main_keyboard())
        return
    
    ticker_data = indodax.get_ticker('btc_idr')
    if 'ticker' not in ticker_data:
        bot.reply_to(message, "❌ Gagal mengambil harga BTC", reply_markup=create_main_keyboard())
        return
    
    last_price = float(ticker_data['ticker'].get('last', 0))
    idr_to_spend = required_amount * 0.998  # with fee buffer
    amount = idr_to_spend / last_price
    
    # Place order
    order_result = indodax.place_order('btc_idr', 'buy', last_price, amount)
    
    if order_result.get('success') == 1:
        order_info = order_result.get('return', {})
        executed_price = float(order_info.get('order_price', last_price))
        executed_amount = float(order_info.get('remain_btc', amount))
        actual_total = executed_price * executed_amount
        
        success_text = f"""
✅ BUY BTC Rp 100rb BERHASIL
📊 HARGA REAL INDODAX

🪙 Amount: {executed_amount:.8f} BTC
💰 Harga: Rp {format_number(executed_price)}
💵 Total: Rp {format_number(actual_total)}
🆔 Order ID: {order_info.get('order_id', 'N/A')}
        """
        
        bot.reply_to(message, success_text, reply_markup=create_main_keyboard())
    else:
        error_msg = order_result.get('error', 'Gagal buy')
        bot.reply_to(message, f"❌ Error: {error_msg}", reply_markup=create_main_keyboard())

@bot.message_handler(func=lambda message: message.text == '💸 Jual Semua')
def sell_all_to_idr(message):
    """Sell all crypto to IDR"""
    bot.reply_to(message, "⏳ Jual semua crypto ke IDR...")
    
    # Get balance
    balance_data = indodax.get_balance()
    if balance_data.get('success') != 1:
        bot.reply_to(message, "❌ Gagal mengambil balance", reply_markup=create_main_keyboard())
        return
    
    balance = balance_data.get('return', {}).get('balance', {})
    btc_balance = float(balance.get('btc', 0))
    sol_balance = float(balance.get('sol', 0))
    
    results = []
    total_idr_earned = 0
    
    # Sell BTC if available
    if btc_balance >= 0.00001:
        btc_ticker = indodax.get_ticker('btc_idr')
        if 'ticker' in btc_ticker:
            btc_price = float(btc_ticker['ticker'].get('last', 0))
            btc_order = indodax.place_order('btc_idr', 'sell', btc_price, btc_balance)
            
            if btc_order.get('success') == 1:
                btc_idr = btc_price * btc_balance
                total_idr_earned += btc_idr
                results.append(f"🪙 BTC: {btc_balance:.8f} → Rp {format_number(btc_idr)}")
            else:
                results.append(f"❌ BTC: {btc_order.get('error', 'Gagal jual')}")
    
    # Sell SOL if available
    if sol_balance >= 0.001:
        sol_ticker = indodax.get_ticker('sol_idr')
        if 'ticker' in sol_ticker:
            sol_price = float(sol_ticker['ticker'].get('last', 0))
            sol_order = indodax.place_order('sol_idr', 'sell', sol_price, sol_balance)
            
            if sol_order.get('success') == 1:
                sol_idr = sol_price * sol_balance
                total_idr_earned += sol_idr
                results.append(f"🔥 SOL: {sol_balance:.6f} → Rp {format_number(sol_idr)}")
            else:
                results.append(f"❌ SOL: {sol_order.get('error', 'Gagal jual')}")
    
    # Create result message
    if results:
        result_text = "💸 HASIL JUAL SEMUA KE IDR\n\n"
        result_text += "\n".join(results)
        if total_idr_earned > 0:
            result_text += f"\n\n💰 Total: Rp {format_number(total_idr_earned)}"
        
        bot.reply_to(message, result_text, reply_markup=create_main_keyboard())
    else:
        bot.reply_to(message, "❌ Tidak ada crypto untuk dijual", reply_markup=create_main_keyboard())

def main():
    """Main function to run the bot"""
    print("🚀 Starting Simple Indodax Trading Bot...")
    print("🔗 Bot is ready and waiting for messages...")
    
    try:
        bot.infinity_polling(none_stop=True)
    except Exception as e:
        print(f"❌ Error occurred: {e}")
        print("🔄 Restart bot untuk mencoba lagi...")

if __name__ == "__main__":
    main()